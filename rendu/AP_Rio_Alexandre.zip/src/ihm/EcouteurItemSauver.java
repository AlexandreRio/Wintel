package ihm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import datas.*;

public class EcouteurItemSauver implements ActionListener {

   private Wintel theWin;

   public EcouteurItemSauver(Wintel monWin) {
      this.theWin = monWin;
   }

   /**
    *
    */
   public void actionPerformed (ActionEvent e) {
      Annuaire theAnnuaire = theWin.getAnnuaire();
      theAnnuaire.sauver();
   }
}
