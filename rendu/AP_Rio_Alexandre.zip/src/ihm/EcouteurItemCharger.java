package ihm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import datas.*;

public class EcouteurItemCharger implements ActionListener {

   private Wintel theWin;

   public EcouteurItemCharger (Wintel monWin) {
      this.theWin = monWin;
   }

   /**
    *
    */
   public void actionPerformed (ActionEvent e) {
      theWin.chargerEtAfficherAnnuaire();
   }

}
