package ihm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import datas.*;

public class WtDialogAjouter extends JDialog {

}
