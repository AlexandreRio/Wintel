package datas;

import java.util.Hashtable;

public class TableFiches {

   /**
    * Gets all the Fiche in the file table.bin
    * @return All the Fiche in a Hashtable
    */
   public static Hashtable<String, Fiche> lireTableFiches() {
      Hashtable<String, Fiche> listFiche = new Hashtable<String, Fiche>();

      return listFiche;
   }
}
